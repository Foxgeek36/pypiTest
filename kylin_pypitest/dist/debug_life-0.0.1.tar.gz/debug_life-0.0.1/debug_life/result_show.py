def out_put():
	print('Anything is possible!')
	print('I am the spiderman!')